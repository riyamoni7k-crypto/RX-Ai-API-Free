<?php

// Capture phone number from GET request
$phone = $_GET['phone'] ; // Default phone number if not provided

// Set up the cURL request
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://api-v2.gadgetandgear.com/api/v1/auth/customer/send-otp');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

// Set headers, replacing User-Agent as specified
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'User-Agent: Mozilla/5.0 (Linux; Android 7.0; HUAWEI P30) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36',
    'Accept: application/json, text/plain, */*',
    'Accept-Language: en-US,en;q=0.5',
    
    'Content-Type: application/json',
    'Origin: https://gadgetandgear.com',
    'Connection: keep-alive',
    'Referer: https://gadgetandgear.com/',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: same-site',
    'Priority: u=1',
]);

// Set the JSON payload with the phone number and type
$data = json_encode([
    'phone' => $phone,
    'type' => 'register'
]);

curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

// Execute the request
$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

// Check for errors
if ($err) {
    echo "cURL Error #:" . $err;
} else {
    echo $response;
}
?>
