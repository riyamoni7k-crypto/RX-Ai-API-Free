<?php
// Get the tel parameter from GET request
$tel = isset($_GET['phone']) ? $_GET['phone'] : '';

// Remove leading '0' if present
if (strpos($tel, '0') === 0) {
    $tel = substr($tel, 1);
}

// Prepare the data payload
$data = [
    'tel' => $tel,
    'appId' => 'M201',
    'sign' => '',
    'deviceNumber' => '1a05a600dea455f74d4eaa3a54fc938d',
    'uid' => '',
    'fromSource' => 'APP_M201_1',
    'appVersion' => '2.0',
    'language' => 'en',
    'adid' => '6294593200eede610fe883c26cd467d7',
    'mobileModel' => 'ITELitel S665L',
    'gpsAdid' => 'f4109953-da9f-4acd-87b8-b3931cea04ee'
];

// Initialize cURL
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, 'https://www.rbgame.info/sms/send');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Accept-Encoding: identity',
    'Content-Type: application/json',
    'User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; itel S665L Build/SP1A.210812.016)',
    'Host: www.rbgame.info',
    'Connection: Keep-Alive',
    'Content-Length: ' . strlen(json_encode($data))
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// Execute the request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}

// Close cURL
curl_close($ch);

// Output the response
echo $response;
?>