<?php
// Function to generate a random Gmail address
function generateRandomGmail() {
    $randomString = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789"), 0, 10);
    return $randomString . "@gmail.com";
}

// Capture phone number from GET request

$phone = ltrim($_GET["phone"], '0'); // Trim leading 0 from phone number

// Generate a random Gmail address
$email = generateRandomGmail();
$password = "Moman@#2024";  // Replace this with your actual password securely

// Initialize curl session
$ch = curl_init();

// Setup the curl request with required headers and data
curl_setopt_array($ch, [
    CURLOPT_URL => "https://user.bdapps.com/registration-api/api/v3/robi/profile/sp",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        "username" => "a".$phone,
        "email" => $email,
        "msisdn" => "880" . $phone,
        "password" => $password,
        "verificationMethod" => "sms"
    ]),
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
    ]
]);

// Execute curl and capture response
$response = curl_exec($ch);

// Check for errors
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    echo "BDApps Reg: " . $response;
}

// Close curl session
curl_close($ch);
?>
