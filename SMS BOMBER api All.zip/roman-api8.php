<?php
// WebShare.io প্রোক্সি কনফিগারেশন
$proxyIP = '38.154.227.167';
$proxyPort = '5868';
$proxyUsername = 'axyyxcvg';
$proxyPassword = 'dkaf2mppq74s';

// টার্গেট API URL
$apiUrl = 'https://b08.abcd43.com/api/auth/registerNumber';

// মোবাইল নাম্বার GET প্যারামিটার থেকে নিন (01719764189 ফরম্যাটে)
$mobileNumber = isset($_GET['mobileNumber']) ? ltrim($_GET['mobileNumber'], '0') : '';

// রিকোয়েস্ট ডাটা প্রস্তুত করুন
$postData = [
    'countryCode' => '+880',
    'mobileNumber' => $mobileNumber,
    'promoCode' => '',
    'atag' => '',
    'clickId' => '',
    'userAgent' => 'Mozilla/5.0 (Linux; Android 12; itel S665L Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.135 Mobile Safari/537.36',
    'fbp' => '',
    'fbc' => 'fb.1.1743755949531.137846220276185190',
    'channel' => 'WHATSAPP'
];

// cURL ইনিশিয়ালাইজ করুন
$ch = curl_init();

// প্রোক্সি সেটআপ
curl_setopt($ch, CURLOPT_PROXY, $proxyIP.':'.$proxyPort);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyUsername.':'.$proxyPassword);

// বেসিক cURL অপশনস
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // SSL ভেরিফিকেশন বন্ধ (ডেভেলপমেন্টের জন্য)
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

// হেডার সেট করুন
$headers = [
    'Content-Type: application/json',
    'User-Agent: Mozilla/5.0 (Linux; Android 12; itel S665L Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.135 Mobile Safari/537.36',
    'Accept: application/json',
    'Origin: https://bangla11.com',
    'Referer: https://bangla11.com/'
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// রিকোয়েস্ট এক্সিকিউট করুন
$response = curl_exec($ch);

// এরর হ্যান্ডেলিং
if (curl_errno($ch)) {
    $errorMsg = curl_error($ch);
    $result = [
        'status' => 'error',
        'message' => 'cURL Error: '.$errorMsg,
        'proxy' => $proxyIP.':'.$proxyPort,
        'http_code' => curl_getinfo($ch, CURLINFO_HTTP_CODE)
    ];
} else {
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $result = [
        'status' => 'success',
        'http_code' => $httpCode,
        'response' => json_decode($response, true),
        'proxy' => $proxyIP.':'.$proxyPort
    ];
}

// cURL ক্লোজ করুন
curl_close($ch);

// আউটপুট JSON ফরম্যাটে প্রদর্শন করুন
header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>