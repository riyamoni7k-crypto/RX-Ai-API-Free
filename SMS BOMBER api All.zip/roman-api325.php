<?php

$phn = $_REQUEST["phone"];
$url = "https://api.swap.com.bd/api/v1/send-otp/v2";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Content-Type: application/json",
    "Accept: application/json, text/plain, */*",
    "Accept-Language: en-US,en;q=0.9,ru;q=0.8",
    "Connection: keep-alive",
    "Origin: https://swap.com.bd",
    "Referer: https://swap.com.bd/",
    "Sec-Fetch-Dest: empty",
    "Sec-Fetch-Mode: cors",
    "Sec-Fetch-Site: same-site",
    "signature: qXY5pikMhFVO4MqrvFLhzhnA2nAeC4EttIiei11nxUA="
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$ps = array(
    "phone" => $phn
);

$data = json_encode($ps);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// For debug only! You should consider removing these lines in production.
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
echo($resp);

?>
