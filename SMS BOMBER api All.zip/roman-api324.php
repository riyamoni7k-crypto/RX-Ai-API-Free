<?php
// Get phone number from request
$phoneNumber = $_REQUEST["phone"];

// Initialize a cURL session
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://api.bdtickets.com:20100/v1/auth");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);

// Set timeout options
curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Timeout in seconds
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); // Connection timeout in seconds

// Set headers
$headers = [
    "Accept: application/json, text/plain, */*",
    "Accept-Language: en-US,en;q=0.9,ru;q=0.8",
    "Content-Type: application/json",
    "Origin: https://www.bdtickets.com",
    "Priority: u=1, i",
    "Referer: https://www.bdtickets.com/",
    "sec-ch-ua: \"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
    "sec-ch-ua-mobile: ?0",
    "sec-ch-ua-platform: \"Windows\"",
    "sec-fetch-dest: empty",
    "sec-fetch-mode: cors",
    "sec-fetch-site: same-site",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Create JSON payload
$data = json_encode([
    "createUserCheck" => true,
    "phoneNumber" => "+88" . $phoneNumber,
    "applicationChannel" => "WEB_APP"
]);

curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

// Execute the cURL session and get the response
$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    echo $response;
}

curl_close($ch);
?>
