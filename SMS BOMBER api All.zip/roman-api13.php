<?php

// Step 1: Get the phone number from the query parameters
$phone = $_GET['phone'] ?? '';

if (empty($phone)) {
    echo 'Error: Phone number is required';
    exit;
}

// Step 2: Validate if the phone number starts with 013 or 017
if (preg_match('/^013|017/', $phone) === 0) {
    echo 'Error: This is not a GP number';
    exit;
}

// Step 3: Set the target URL for the API request
$url = "https://gpglobal.b2mwap.com/api/subscription?keyword=GSD&msisdn=88" . urlencode($phone);

// Step 4: Set the custom User-Agent header for the request
$userAgent = "Mozilla/5.0 (Linux; U; Android 5.0.2; SAMSUNG SM-A800T Build/LMY47X) AppleWebKit/533.43 (KHTML, like Gecko) Chrome/49.0.1121.309 Mobile Safari/603.1";

// Step 5: Initialize the cURL session
$ch = curl_init($url);

// Step 6: Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // To return the response instead of outputting it
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);  // Set the custom User-Agent
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  // Follow redirects

// Step 7: Execute the cURL request
$response = curl_exec($ch);

// Step 8: Get the HTTP response status code
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Step 9: Check for any cURL errors
if (curl_errno($ch)) {
    echo 'cURL Error: ' . curl_error($ch);
} else {
    // Step 10: Check the status code for success (200)
    if ($httpCode == 200) {
        echo 'SMS sent successfully';
    } else {
        echo 'Error: SMS could not be sent. HTTP Status Code: ' . $httpCode;
    }
}

// Step 11: Close the cURL session
curl_close($ch);

?>
