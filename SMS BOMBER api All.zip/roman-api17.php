<?php
// Initialize a cURL session
$ch = curl_init();

// The URL to send the request to
$url = 'https://channels.mevrik.com:4202/init-chat';

// Data to be sent in the POST request (JSON format)
$data = json_encode([
    'channel' => 'gp-website',
    'utm_source' => 'www.grameenphone.com'
]);

// Set the necessary cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1); // Set POST method
curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // Attach the JSON data
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response instead of outputting it

// Set the HTTP headers, including User-Agent and Content-Type
$headers = [
    'Content-Type: application/json',
    'User-Agent: Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36'
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Execute the cURL request
$response = curl_exec($ch);

// Check for any errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
} else {
    // Decode the JSON response
    $responseData = json_decode($response, true);

    // Check if "token" exists in the response
    if (isset($responseData['token'])) {
        // Output the token
        echo $responseData['token'];
    } else {
        echo 'Token not found in the response.';
    }
}

// Close the cURL session
curl_close($ch);
?>
