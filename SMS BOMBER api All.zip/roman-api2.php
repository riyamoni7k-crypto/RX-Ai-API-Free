<?php
// Get phone number from GET parameter
$mobileNo = isset($_GET['phone']) ? $_GET['phone'] : '';
$countryDialingCode = isset($_GET['countryDialingCode']) ? $_GET['countryDialingCode'] : '880';

// Validate input
if (empty($mobileNo)) {
    die("Phone number is required");
}

$url = 'https://www.ai99s.com/wps/verification/sms/register';
$data = json_encode([
    'mobileNo' => $mobileNo,
    'countryDialingCode' => $countryDialingCode
]);

$headers = [
    'Host: www.ai99s.com',
    'Connection: keep-alive',
    'Content-Length: ' . strlen($data),
    'Language: EN',
    'sec-ch-ua-platform: "Android"',
    'Authorization: ',
    'sec-ch-ua: "Chromium";v="134", "Not:A-Brand";v="24", "Android WebView";v="134"',
    'sec-ch-ua-mobile: ?1',
    'Merchant: ai99bdtf5',
    'ModuleId: REGMOBVERF3',
    'User-Agent: Mozilla/5.0 (Linux; Android 12; itel S665L Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.135 Mobile Safari/537.36',
    'Accept: application/json, text/plain, */*',
    'Content-Type: application/json',
    'Origin: https://www.ai99s.com',
    'X-Requested-With: mark.via.gp',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://www.ai99s.com/m/register?affiliateCode=yuumi03&fbclid=IwY2xjawJbKsNleHRuA2FlbQEwAGFkaWQBqxqtYJgGcwEd0BM62mmSIca9MvkC_1bDftzTovqmUjGuhXFKjWe0RQUjT5gU1R-IAN6U_aem_HNB8FxlH83Rxa3msnZ6YAw&utm_medium=paid&utm_source=fb&utm_id=120219146863420355&utm_content=120219146917810355&utm_term=120219146863430355&utm_campaign=120219146863420355',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: SHELL_deviceId=3418f42b-d0ca-4e5f-8e5b-b968deb26410; _fbc=fb.1.1743670207183.IwY2xjawJbKsNleHRuA2FlbQEwAGFkaWQBqxqtYJgGcwEd0BM62mmSIca9MvkC_1bDftzTovqmUjGuhXFKjWe0RQUjT5gU1R-IAN6U_aem_HNB8FxlH83Rxa3msnZ6YAw; _fbp=fb.1.1743670207220.335253546411901573'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_ENCODING, ''); // Enable compression

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    echo $response;
}

curl_close($ch);
?>


