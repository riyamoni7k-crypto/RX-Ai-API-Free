<?php
$phn = $_REQUEST["phone"];
$url = "https://api.ghoorilearning.com/api/auth/signup/otp?_app_platform=web&_lang=bn";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Linux; Android 9; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36",
    "Content-Type: application/json",
    "Referer: https://ghoorilearning.com/",
    "Origin: https://ghoorilearning.com",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$ps = array(
    "mobile_no" => $phn
);
$data = json_encode($ps);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);

// Pretty print the response
$decoded_resp = json_decode($resp, true);
if ($decoded_resp) {
    // Output the JSON with unescaped Unicode characters
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($decoded_resp, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo "Invalid JSON response: " . $resp;
}
?>
