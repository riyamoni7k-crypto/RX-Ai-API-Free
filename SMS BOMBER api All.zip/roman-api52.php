<?php
// Set the content type to handle UTF-8 characters for Bangla
header('Content-Type: application/json; charset=UTF-8');

// Get the phone number from the query string
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';

// Check if the phone number is provided
if (!empty($phone)) {
    // API URL
    $url = 'https://developer.medha.info/api/send-otp';
    
    // Data to be sent in the POST request
    $postData = array(
        'phone' => $phone,
        'is_register' => '1'
    );

    // Initialize cURL session
    $ch = curl_init($url);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'User-Agent: Mozilla/5.0 (Linux x86_64; en-US) AppleWebKit/536.24 (KHTML, like Gecko) Chrome/53.0.1963.164 Safari/536'
    ));

    // Execute the request
    $response = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        // Error message in Bangla
        $result = array('status' => 'error', 'message' => 'একটি ত্রুটি ঘটেছে: ' . curl_error($ch));
    } else {
        // Decode the response and check for JSON errors
        $decodedResponse = json_decode($response, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            // Success message in Bangla
            $result = array('response' => $decodedResponse);
        } else {
            // Error message in Bangla for invalid JSON response
            $result = array('status' => 'error', 'message' => 'অবৈধ JSON প্রতিক্রিয়া');
        }
    }

    // Close the cURL session
    curl_close($ch);
} else {
    // Error message in Bangla for missing phone number
    $result = array('status' => 'error', 'message' => 'ফোন নম্বরটি অনুপস্থিত');
}

// Output the result as prettified JSON with unescaped Unicode
echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
