<?php
// Check if the phone parameter is passed in the URL
if(isset($_GET['phone'])) {
    $phone = $_GET['phone'];
    
    // URL to send the POST request
    $url = "https://bb-api.bohubrihi.com/public/activity/otp";
    
    // Prepare the data to be sent
    $data = array(
        'phone' => $phone,
        'intent' => 'login'
    );

    // Initialize cURL
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // To return the result
    curl_setopt($ch, CURLOPT_POST, true); // Use POST request
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json', // Setting content type to JSON
        'User-Agent: Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36'
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // Send JSON-encoded data

    // Execute the request and get the response
    $response = curl_exec($ch);

    // Check for any cURL errors
    if (curl_errno($ch)) {
        echo 'cURL error: ' . curl_error($ch);
    } else {
        // Display the response
        echo $response;
    }

    // Close the cURL session
    curl_close($ch);
} else {
    echo "Phone number is not provided!";
}
?>
