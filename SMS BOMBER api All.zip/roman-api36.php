<?php
$phone = $_GET['phone'];

// Validate phone number for GP pattern
if (preg_match('/^017|013/', $phone)) {

    // Token API URL
    $tokenUrl = 'https://abinfotechnologies.com/wp-admin/api/gplivechat-token.php';

    // Fetch token from the token API
    $chToken = curl_init($tokenUrl);
    curl_setopt($chToken, CURLOPT_RETURNTRANSFER, true);
    $tokenResponse = curl_exec($chToken);

    // Error handling for token retrieval
    if (curl_errno($chToken)) {
        echo 'Token Fetch Error:' . curl_error($chToken);
        curl_close($chToken);
        exit;
    }

    curl_close($chToken);

    // Assume the response is the token, you might need to decode the response depending on its format
    $token = trim($tokenResponse);

    if (empty($token)) {
        echo "Failed to retrieve token.";
        exit;
    }

    // Define the API URL for claim session
    $url = 'https://channels.mevrik.com:4202/api/v1/claim-session';

    // Prepare data payload
    $data = [
        'data' => [
            'user_ref' => $phone,
            'name' => 'Karim Mia' // You can make this dynamic if needed
        ]
    ];

    // Convert data array to JSON
    $jsonData = json_encode($data);

    // Set the headers including the token
    $headers = [
        'Content-Type: application/json',
        'x-mevrik-token: ' . $token
    ];

    // Initialize cURL for the claim session request
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the cURL request
    $response = curl_exec($ch);

    // Error handling for the cURL request
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        echo 'Response: ' . $response;
    }

    // Close the cURL session
    curl_close($ch);
} else {
    echo "This is not a valid GP number.";
}
?>
