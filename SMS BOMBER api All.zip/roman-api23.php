<?php
// Get phone number from GET parameter (without +88)
$phone_part = isset($_GET['phone']) ? $_GET['phone'] : '';

// Add +88 as prefix (default)
$full_phone = '+88' . $phone_part;

// API endpoint
$url = 'http://bjst170.qo7k.com/api/game/app/exclude/bindPhoneCodeNoImgCode';

// Request data
$data = array(
    'id' => 0,
    'projectSign' => 'bjst170',
    'phone' => $full_phone
);
$json_data = json_encode($data);

// Headers
$headers = array(
    'Accept-Encoding: identity',
    'Accept-Language: be',
    'Content-Type: application/json',
    'User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; itel S665L Build/SP1A.210812.016)',
    'Host: bjst170.qo7k.com',
    'Connection: Keep-Alive',
    'Content-Length: ' . strlen($json_data)
);

// Initialize cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_ENCODING, ''); // Handles compression

// Execute and get response
$response = curl_exec($ch);

// Check for errors
if(curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    // Output the response
    echo $response;
}

// Close connection
curl_close($ch);
?>