<?php
// Get the phone number from the GET request
$phone = $_GET['phone'];

// Check if the phone number starts with '017' or '013'
if (preg_match('/^(017|013)/', $phone)) {
    // Initialize cURL
    $url = "https://webloginda.grameenphone.com/backend/api/v1/otp";
    
    $data = array("msisdn" => $phone);
    $payload = json_encode($data);

    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'User-Agent: Mozilla/5.0'
    ));

    // Execute cURL request
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        
        echo 'Response: ' . $response;
    }

    // Close cURL session
    curl_close($ch);
} else {
    // Phone number does not start with '017' or '013'
    echo "This is not a GP number";
}
?>