<?php

// Capture the 'phone' parameter from the URL
$phn = isset($_GET['phone']) ? $_GET['phone'] : '';  // Check if 'phone' parameter exists

if (!empty($phn)) {  // Ensure that the phone number is not empty

    $url = "https://www.amiprobashi.com/api/v7/en/auth/send-otp";

    // Initialize cURL session
    $curl = curl_init($url);

    // Set cURL options
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    // Array of possible User-Agent strings
    $userAgents = [
        "Mozilla/5.0 (Windows; U; Windows NT 6.0; x64) Gecko/20100101 Firefox/56.7",
        "Mozilla/5.0 (compatible; MSIE 11.0; Windows; U; Windows NT 6.3; WOW64; en-US Trident/7.0)",
        "Mozilla/5.0 (Linux; U; Linux x86_64; en-US) Gecko/20130401 Firefox/67.7",
        "Mozilla/5.0 (Windows NT 10.1; x64) AppleWebKit/602.43 (KHTML, like Gecko) Chrome/48.0.3938.294 Safari/536.9 Edge/11.69487",
        "Mozilla/5.0 (Linux; U; Android 7.1.1; LG-H910 Build/NRD90C) AppleWebKit/603.27 (KHTML, like Gecko) Chrome/52.0.2025.310 Mobile Safari/534.4",
        "Mozilla/5.0 (compatible; MSIE 7.0; Windows; Windows NT 6.3; WOW64 Trident/4.0)",
        "Mozilla/5.0 (Windows; Windows NT 6.1; WOW64; en-US) AppleWebKit/600.22 (KHTML, like Gecko) Chrome/50.0.1275.357 Safari/535.7 Edge/14.29364",
        "Mozilla/5.0 (iPod; CPU iPod OS 8_9_0; like Mac OS X) AppleWebKit/537.2 (KHTML, like Gecko) Chrome/50.0.1343.276 Mobile Safari/536.4",
        "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.2; WOW64; en-US Trident/4.0)",
        "Mozilla/5.0 (Linux; Android 7.0; Xperia V Build/NDE63X) AppleWebKit/601.24 (KHTML, like Gecko) Chrome/54.0.2779.358 Mobile Safari/601.4"
    ];

    // Randomly select a User-Agent
    $randomUserAgent = $userAgents[array_rand($userAgents)];

    // Set HTTP headers including the random User-Agent
    $headers = array(
        "Content-Type: application/x-www-form-urlencoded",
        "User-Agent: $randomUserAgent"
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    // Set POST data
    $data = "device_type=1&device_key=cfyS5kcSTuK6ZnMWRL-OtX%253AAPA91bFUkY1GSeCv0HWscGmoLpOtg2UFvt7OTEgdg6Ej_pL63Wjfw5kTjzXegjAPWQFV80UyUKcF0zWBB2ArwNSlevmR4ZJAg67SywNrhsuReYro7xGAamZoG3paCXD_dLiSYuMP-E9u&username=" . urlencode($phn) . "&for=1&type=1&bd_number=1";
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    // Enable for debugging only: Disables SSL certificate verification
    // WARNING: Do not use the following lines in production
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    // Execute cURL request
    $resp = curl_exec($curl);

    // Check for errors and handle the response
    if ($resp === false) {
        $error = curl_error($curl);
        echo "cURL Error: $error";
    } else {
        // Handle the response (for now, just print it out)
        echo($resp);
    }

    // Close cURL session
    curl_close($curl);

} else {
    echo "No phone number provided.";
}

?>