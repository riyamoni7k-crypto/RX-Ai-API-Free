<?php

// Retrieve the phone number from the GET request
$phn = isset($_GET['phone']) ? $_GET['phone'] : '';

if ($phn) {
    $url = "https://joyquiz.pro/verify_msisdn.html";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $headers = array(
       "Content-Type: application/x-www-form-urlencoded",
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    // Prepare the data for the POST request
    $data = "service=playcloud&entered_msisdn=" . urlencode($phn);

    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    // For debug only, disable SSL verification (not recommended for production)
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $resp = curl_exec($curl);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    // Check the HTTP response code
    if ($http_code == 200) {
        echo "Joy Quiz OTP sent successfully.";
    } else {
        echo "Failed to send OTP. HTTP Response Code: " . $http_code;
    }
} else {
    echo "Phone number is required.";
}

?>