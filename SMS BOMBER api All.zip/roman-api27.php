<?php
// Retrieve phone number from GET request
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';

// Check if phone number starts with '016' or '018'
if (strpos($phone, '016') === 0 || strpos($phone, '018') === 0) {
    // Format the phone number to start with '880' for the request
    $msisdn = '880' . substr($phone, 1);

    // Initialize cURL
    $curl = curl_init();

    // Set cURL options
    curl_setopt_array($curl, [
        CURLOPT_URL => 'https://airtelscreen.com/index.php/home/forgotpass',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'User-Agent: Mozilla/5.0 (Linux; Android 11; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36',
            'Content-Type: application/x-www-form-urlencoded',
        ],
        CURLOPT_POSTFIELDS => http_build_query([
            'msisdn-forgot' => $msisdn,
            'forgot-submit' => 'Send Password',
        ]),
    ]);

    // Execute cURL request
    $response = curl_exec($curl);

    // Check for cURL errors
    if (curl_errno($curl)) {
        echo 'cURL error: ' . curl_error($curl);
    } else {
        // Output response message
        echo 'You will get the password in the SMS Inbox From Airtel Screen.';
    }

    // Close cURL session
    curl_close($curl);
} else {
    // If the number does not start with '016' or '018', output error message
    echo 'Please use a Robi/Airtel Number to use the service!';
}
?>
