<?php
// Retrieve phone number from GET request and ensure it starts with '01'
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';
if (substr($phone, 0, 2) !== '01') {
    die('Phone number must start with 01.');
}

// Replace the leading '01' with the full international format if needed
// Assuming the replacement means adding '880' for Bangladesh
$msisdn = '880' . substr($phone, 1);

// Initialize cURL
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api-bl-v3.boighor.com.bd/api/signup',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_HTTPHEADER => [
        'User-Agent: Mozilla/5.0 (Linux; Android 11; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36',
        'Accept: application/json, text/plain, */*',
        'Accept-Language: en-US,en;q=0.5',
        'Accept-Encoding: gzip, deflate, br, zstd',
        'Content-Type: multipart/form-data; boundary=---------------------------181327550515570057262199291517',
        'Origin: https://boighor.com.bd',
        'Connection: keep-alive',
        'Referer: https://boighor.com.bd/',
        'Sec-Fetch-Dest: empty',
        'Sec-Fetch-Mode: cors',
        'Sec-Fetch-Site: same-site',
        'Priority: u=1',
    ],
    CURLOPT_POSTFIELDS => "-----------------------------181327550515570057262199291517\r\n" .
        "Content-Disposition: form-data; name=\"retrieve\"\r\n\r\n1\r\n" .
        "-----------------------------181327550515570057262199291517\r\n" .
        "Content-Disposition: form-data; name=\"msisdn\"\r\n\r\n$msisdn\r\n" .
        "-----------------------------181327550515570057262199291517\r\n" .
        "Content-Disposition: form-data; name=\"fromsrc\"\r\n\r\nweb\r\n" .
        "-----------------------------181327550515570057262199291517--\r\n",
]);

// Execute cURL request
$response = curl_exec($curl);

// Check for cURL errors
if (curl_errno($curl)) {
    echo 'cURL error: ' . curl_error($curl);
} else {
    // Output the response
    echo $response;
}

// Close cURL session
curl_close($curl);
?>
