<?php

$phn = $_REQUEST["phone"];
$url = "https://api-front.ekshop.gov.bd/api/initotp";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Content-Type: application/json",
    "x-api-client: desktop",
    "x-auth-token;"
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$ps = array(
    "phone_number" => $phn,
    "country_code" => "+88",
    "phone" => $phn
);

$data = json_encode($ps);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// For debugging only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
echo $resp;

?>
