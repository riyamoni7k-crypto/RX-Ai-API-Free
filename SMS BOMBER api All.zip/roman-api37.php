<?php
$phn=$_GET["phone"];


$url = 'https://scs.robi.com.bd/api/send-otp';

$headers = [
    'User-Agent: okhttp/3.12.0',
    'Connection: Keep-Alive',
    'Accept: application/json',
    
    'Content-Type: multipart/form-data',
    'App-Env: stage',
    'Sms-Hash-Key: 3LtW7kkzMXS',
    'DeviceId: 95cdc0814c3178b0',
    'Device: 1',
    'AppVersionCode: 17',
    'Accept-Language: en',
    'OS-Version: 11',
    'Device-Info: realme-RMX3171',
    'MacAddress: NO MACADDRESS',
    'Imei: NO IMEI',
    'Authorization: Bearer'
];

$params = [
    'mobile_no' => $phn
];

// Initialize a cURL session
$ch = curl_init();

// Set the URL and other options
curl_setopt($ch, CURLOPT_URL, $url . '?' . http_build_query($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Execute the request and fetch the response
$response = curl_exec($ch);

// Close the cURL session
curl_close($ch);
echo $response

?>