<?php
$phn=$_GET["phone"];
$url = "https://otithee.com/api/myaccount/generate_otp?username=api%40otithee.com&password=mfbzHr-D4efb-U4jg8r-LKxHm";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "user-agent: Monibot",
   "Content-Type: application/x-www-form-urlencoded",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

//$data = "mobile_number=013230&email=t%4040gmail.com";
$ps = array(
"mobile_number"=>$phn,"email"=>"t4040@gmail.com"
);

$data = http_build_query($ps);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
echo("Frpm Oithee:");
echo($resp);

?>

