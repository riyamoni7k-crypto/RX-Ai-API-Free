<?php

for ($i = 0; $i < 1; $i++) {
    $phoneNumber = $_REQUEST["phone"];
    $url = "https://api.englishmojabd.com/api/v1/auth/login";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $headers = array(
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Content-Type: application/json",
        "Origin: https://www.englishmojabd.com",
        "Referer: https://www.englishmojabd.com/",
        "Sec-Fetch-Dest: empty",
        "Sec-Fetch-Mode: cors",
        "Sec-Fetch-Site: same-site",
        "Sec-Ch-UA: 'Chromium';v='122', 'Not(A:Brand';v='24', 'Google Chrome';v='122')",
        "Sec-Ch-UA-Mobile: ?0",
        "Sec-Ch-UA-Platform: Windows"
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    $ps = array(
        "phone" => "+88" . $phoneNumber
    );

    $data = json_encode($ps);

    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    // For debug only!
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $resp = curl_exec($curl);
    curl_close($curl);
    echo $resp;
}

?>
