<?php

// Check if the phone number is provided via GET request
if(isset($_GET['phone'])) {
    $phone = $_GET['phone'];
    
    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, "https://bkwebsitethc.grameenphone.com/api/v1/star-program/check-status");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);

    // Prepare the data to be sent via POST
    $data = json_encode(array("msisdn" => $phone));

    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'User-Agent: Mozilla/5.0 (Linux; Android 12; Moto G Power) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Mobile Safari/537.36'
    ));

    // Execute cURL request and fetch response
    $response = curl_exec($ch);

    // Check for errors
    if(curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        // Output the response
        echo $response;
    }

    // Close cURL session
    curl_close($ch);
} else {
    echo "Phone number not provided.";
}

?>
