<?php
// api_request_sender.php

function validatePhone($phone) {
    return preg_match('/^01[3-9]\d{8}$/', $phone);
}

function sendApiRequest($apiUrl, $phone, $isCobra = false) {
    $param = $isCobra ? 'num' : 'phone';
    $url = $apiUrl . (strpos($apiUrl, '?') === false ? '?' : '&') . $param . '=' . urlencode($phone);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    // SSL handling for cobraCll.php
    if ($isCobra) {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // Disable host verification
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        ]);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    return [
        'status' => ($httpCode == 200) ? 'success' : 'error',
        'code' => $httpCode,
        'response' => $response ?: $error
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $phone = isset($_GET['phone']) ? trim($_GET['phone']) : '';
    
    if (empty($phone) || !validatePhone($phone)) {
        die(json_encode(['error' => 'Invalid Bangladeshi phone number. Use format: 01712345678']));
    }

    $apiEndpoints = [
        ['url' => 'call.php', 'isCobra' => false],
        ['url' => 'call2.php', 'isCobra' => false],
        ['url' => 'call3.php', 'isCobra' => false],
        ['url' => 'https://mrn-bio.social-networking.me/cobraCll.php', 'isCobra' => true]
    ];

    $baseUrl = 'https://xmod.top/api/';
    $results = [];
    
    foreach ($apiEndpoints as $endpoint) {
        $fullUrl = strpos($endpoint['url'], 'http') === 0 ? 
                 $endpoint['url'] : 
                 $baseUrl . $endpoint['url'];
        
        $results[$endpoint['url']] = sendApiRequest($fullUrl, $phone, $endpoint['isCobra']);
        usleep(100000);
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'phone' => $phone,
        'total_requests' => count($apiEndpoints),
        'results' => $results
    ], JSON_PRETTY_PRINT);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Use GET request.']);
}
?>