<?php
$phn=$_GET["phone"];
// API endpoint
$url = "https://api.busbd.com.bd/api/auth";

// Data to be sent in the POST request
$data = array(
    "phone" => "+88".$phn
);

// JSON encode the data
$jsonData = json_encode($data);

// Initialize cURL session
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0',
    'Accept: application/json, text/plain, */*',
    'Accept-Language: en-US,en;q=0.5',
   'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData),
    'Origin: https://www.busbd.com.bd',
    'Connection: keep-alive',
    'Referer: https://www.busbd.com.bd/',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: same-site',
    'TE: trailers'
));
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);

// Execute the cURL request and get the response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    // Print the response
    echo "Busbd Api:";
    echo $response;
}

// Close cURL session
curl_close($ch);
?>
