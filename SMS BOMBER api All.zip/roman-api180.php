 <?php
$phn=$_GET["phone"];
$url = "https://rootsedulive.com/api/auth/register";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "Content-Type: application/x-www-form-urlencoded",  // Change Content-Type to x-www-form-urlencoded
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = array(
    'name' => 'Pagli Khatun',
    'phone' => '88'.$phn,
    'email' => 'subap'.$phn.'agli2023@gmail.com',
    'password' => 'iDSnWh6rzp9KNAY',
    'confirmPassword' => 'iDSnWh6rzp9KNAY',
);

curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
echo($resp);

?>
