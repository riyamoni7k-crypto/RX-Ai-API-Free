<?php

$url = 'https://api.garibookadmin.com/api/v2/user/login';

$headers = array(
    'User-Agent: Dart/3.3 (dart:io)',
    'Accept: application/json',
    'Accept-Encoding: gzip',
    'Content-Type: application/json',
    'x-requested-with: XMLHttpRequest',
    'authorization: Bearer'
);

$phoneNumber = $_REQUEST["phone"]; // Custom phone number
$gb_code = 'IKiyBy55yYkaF8U'; // Assuming this is constant

$data = array(
    'mobile' => $phoneNumber,
    'gb_code' => $gb_code
);

for ($i = 1; $i <= 5; $i++) {
    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    if ($httpcode == 200) {
        echo "Request $i: Sms Send successful!\n";
        // Process $response if needed
        // For example, $response_data = json_decode($response, true);
    } else {
        echo "Request $i: Login failed. Status code: $httpcode\n";
        echo "Response: $response\n";
    }
}

?>
