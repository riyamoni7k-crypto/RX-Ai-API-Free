<?php
// Get the phone number from the URL query parameter
$phn = $_GET['phone'];

$url = "https://prod.etestpaper.net/api/exists";
$data = json_encode(array("phone" => $phn));

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'User-Agent: Mozilla/5.0'
));
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

$response = curl_exec($ch);
if(curl_errno($ch)) {
    echo 'Request Error:' . curl_error($ch);
} else {
    echo 'Response:' . $response;
}

curl_close($ch);
?>
