<?php

function getAuthToken($tokenUrl) {
    $curl = curl_init($tokenUrl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($curl);
    if ($response === false) {
        echo "cURL Error: " . curl_error($curl);
        curl_close($curl);
        return null;
    }

    curl_close($curl);
    $responseData = json_decode($response, true);
    return isset($responseData['token']) ? $responseData['token'] : null;
}

$phn = $_GET["phone"];
$tokenUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/iscreen-token.php';
$otpUrl = "https://api.rockstreamer.com/otp/api/v1/phone/otp";

$authToken = getAuthToken($tokenUrl);

if (!$authToken) {
    echo "Failed to retrieve auth token.";
    exit;
}

$curl = curl_init($otpUrl);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
   "Authorization: Bearer " . $authToken,
   "Content-Length: " . strlen(json_encode(array("phone_number" => "+88" . $phn))),
   "Origin: https://iscreen.com.bd",
   "Connection: keep-alive",
   "Referer: https://iscreen.com.bd/",
   "Sec-Fetch-Dest: empty",
   "Content-Type: application/json",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = json_encode(array("phone_number" => "+88" . $phn));
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// For debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);

if ($resp === false) {
    $error_message = curl_error($curl);
    // Handle cURL error
    echo "cURL Error: " . $error_message;
} else {
    // Response received successfully
    echo($resp);
}

// Close cURL session
curl_close($curl);

?>
