<?php
// Get the phone number from the query string
$phn = $_GET["phone"];

// Remove leading zeros from the phone number
$phn = ltrim($phn, '0');

// Prepare the data for the cURL request
$data = array(
    "phone_number" => $phn,
    "country_code" => "+880",
    "phone" => $phn
);

// Convert the data to JSON format
$json_data = json_encode($data);

// Initialize cURL session
$ch = curl_init('https://api-front.ekshop.gov.bd/api/initotp');

// Set the cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

// Execute the cURL request and get the response
$response = curl_exec($ch);

// Close the cURL session
curl_close($ch);

// Display the response
echo $response;
?>