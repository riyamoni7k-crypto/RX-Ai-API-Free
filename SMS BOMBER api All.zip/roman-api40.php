<?php
// Get phone number from query string
$phone = $_GET['phone'];

// Initialize a cURL session
$ch = curl_init();

// Set the URL and other options
curl_setopt($ch, CURLOPT_URL, 'https://api.garibookadmin.com/api/v2/user/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);

// Headers array
$headers = [
    'Accept: application/json',
    'Accept-Language: en-US,en;q=0.5',
    
 'Referer: https://garibook.com/',
    'content-type: application/json',
    'Origin: https://garibook.com',
    'Connection: keep-alive',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: cross-site',
    'Priority: u=1',
    // Updated User-Agent for mobile
    'User-Agent: Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36'
];

// Set headers
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// JSON payload
$data = [
    'mobile' => $phone,
    'recaptcha_token' => 'garibookcaptcha'
];

// Set the data payload
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// Execute the cURL session
$response = curl_exec($ch);

// Check for errors
if(curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    // Output the response
    echo $response;
}

// Close the cURL session
curl_close($ch);
?>
