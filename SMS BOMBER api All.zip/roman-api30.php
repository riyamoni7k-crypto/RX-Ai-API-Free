<?php

if (isset($_GET["phone"])) { // Check if 'phone' parameter exists in the request
    $phone = ltrim($_GET["phone"], '0'); // Trim leading 0 from phone number

    $url = "https://user.bdapps.com/registration-api/api/v3/robi/account/recovery";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $headers = array(
        "Content-Type: application/json",
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    // Prepare data with the provided phone number
    $data = json_encode(array("accountRecoveryRequest" =>'a'. $phone));
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    // For debug only!
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    // Execute the request
    $resp = curl_exec($curl);

    if (curl_errno($curl)) {
        // Handle error
        echo "cURL Error: " . curl_error($curl);
    } else {
        // Output the response
        echo($resp);
    }

    curl_close($curl);
} else {
    echo "Error: 'phone' parameter is missing in the request.";
}
?>
