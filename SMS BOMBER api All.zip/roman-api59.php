<?php
// Get the phone number from the query parameter
$phone = $_GET['phone'];

// Initialize cURL session
$ch = curl_init();

// API URL
$url = "http://robiapi.mygamezone.xyz/prod/signup";

// Headers for the cURL request
$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Accept: application/json, text/plain, */*",
    "Accept-Language: en-US,en;q=0.5",
  "Content-Type: multipart/form-data; boundary=---------------------------34820495281097311982511208789",
    "Origin: http://game.robi.com.bd",
    "Connection: keep-alive",
    "Referer: http://game.robi.com.bd/",
    "Priority: u=1"
);

// Multipart form-data for the POST request
$data = "-----------------------------34820495281097311982511208789\r\n";
$data .= "Content-Disposition: form-data; name=\"msisdn\"\r\n\r\n";
$data .= "88".$phone . "\r\n";
$data .= "-----------------------------34820495281097311982511208789\r\n";
$data .= "Content-Disposition: form-data; name=\"retrieve\"\r\n\r\n";
$data .= "0\r\n";
$data .= "-----------------------------34820495281097311982511208789--\r\n";

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

// Execute the cURL request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch);
} else {
    // Output the response
    echo $response;
}

// Close the cURL session
curl_close($ch);
?>
