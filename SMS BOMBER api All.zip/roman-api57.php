<?php
if (isset($_GET['phone'])) {
    $phone = $_GET['phone'];

    $url = 'https://nxpay1.dutchbanglabank.com/user/register';

    $data = array(
        "aspId" => "5678",
        "channel" => null,
        "countryCode" => null,
        "dateOfBirth" => null,
        "email" => null,
        "gender" => null,
        "locale" => "EN",
        "mnoName" => "Robi",
        "msisdn" => $phone,
        "name" => null,
        "nationality" => null,
        "paymentPin" => null,
        "registrationUserId" => $phone,
        "tcidList" => [50],
        "telcoId" => "AT",
        "verificationData" => null,
        "walletPin" => null,
        "walletUserType" => null
    );

    $postData = json_encode($data);

    $headers = array(
        'X-KM-User-MpaId:',
        'X-KM-User-AspId: 5678',
        'X-KM-Accept-language: en',
        'X-KM-OS-SERVICE-TYPE: GMS',
        'X-VersionCode: 100046314',
        'X-KM-User-Agent: ANDROID/100046314',
        'Content-Type: application/json; charset=UTF-8',
        'Content-Length: ' . strlen($postData),
        'Host: nxpay1.dutchbanglabank.com',
        'Connection: Keep-Alive',
        
        'User-Agent: okhttp/4.9.3'
    );

    $options = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_HTTPHEADER => $headers,
    );

    $ch = curl_init();
    curl_setopt_array($ch, $options);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        echo 'Response:' . $response;
    }

    curl_close($ch);
} else {
    echo 'Phone number is missing.';
}
?>