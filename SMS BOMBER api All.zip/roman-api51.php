<?php
// Get phone number from GET parameter
$phoneNumber = isset($_GET['phone']) ? trim($_GET['phone']) : '';

// Validate phone number
if (empty($phoneNumber)) {
    die("Error: Phone number is required");
}

// Remove leading zero if present
if (strpos($phoneNumber, '0') === 0) {
    $phoneNumber = substr($phoneNumber, 1);
}

// Validate the processed number
if (!ctype_digit($phoneNumber)) {
    die("Error: Invalid phone number format");
}

// API endpoint and parameters
$apiUrl = "https://southgrassland.com/tp/sm/send";
$appKey = "TeenPattiStar";
$channelCode = "BSUPU";
$machineId = "b77aac6d31915b286c9cb82dccdd02a9";
$prefix = "55";
$type = "102";

// Prepare the full URL with query parameters
$requestUrl = $apiUrl . "?" . http_build_query([
    'appKey' => $appKey,
    'channelCode' => $channelCode,
    'machineId' => $machineId,
    'phoneNumbers' => $phoneNumber,
    'prefix' => $prefix,
    'type' => $type
]);

// Initialize cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $requestUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For testing only, remove in production

// Execute the request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    die("Error: " . curl_error($ch));
}

// Close cURL
curl_close($ch);

// Output the response
echo "API Response: " . $response;
?>