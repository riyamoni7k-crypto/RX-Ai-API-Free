<?php

$phoneNumber = $_REQUEST["phone"];
$url = "https://prod-api.viewlift.com/identity/otp/resend?site=prothomalo";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Content-Type: application/json",
    "x-api-key: PBSooUe91s7RNRKnXTmQG7z3gwD2aDTA6TlJp6ef"
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = json_encode(array(
    "phoneNumber" => "+88" . $phoneNumber
));

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

// Set these to false for production use
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($curl);
curl_close($curl);

echo $response;

?>
