<?php
$phn=$_GET["phone"];
$url = "https://backoffice.ecourier.com.bd/api/web/individual-send-otp?mobile=".$phn;

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/50509910 Firefox/440",
   "Accept-Language: en-US,en;q=0.5",
   "Origin: https://ecourier.com.bd",
   "Referer: https://ecourier.com.bd/",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
echo($resp);

?>

