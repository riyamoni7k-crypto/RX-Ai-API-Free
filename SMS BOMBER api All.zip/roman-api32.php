<?php
// Retrieve the phone number from the query string
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';

if (!empty($phone)) {
    // Initialize cURL session
    $curl = curl_init();

    // Set cURL options
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'http://robiapi.mygamezone.xyz/prod/signup',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => '-----------------------------22134458039700667251768711927' . "\r\n" .
                              'Content-Disposition: form-data; name="msisdn"' . "\r\n\r\n" .
                             '88'. $phone . "\r\n" .
                              '-----------------------------22134458039700667251768711927' . "\r\n" .
                              'Content-Disposition: form-data; name="retrieve"' . "\r\n\r\n1\r\n" .
                              '-----------------------------22134458039700667251768711927--' . "\r\n",
        CURLOPT_HTTPHEADER => array(
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0',
            'Accept: application/json, text/plain, */*',
            'Accept-Language: en-US,en;q=0.5',
            'Content-Type: multipart/form-data; boundary=---------------------------22134458039700667251768711927',
            'Origin: http://game.robi.com.bd',
            'Connection: keep-alive',
            'Priority: u=4',
            'Referer: http://game.robi.com.bd/',
            
        ),
    ));

    // Execute cURL request and capture response
    $response = curl_exec($curl);

    // Check for cURL errors
    if (curl_errno($curl)) {
        echo 'cURL error: ' . curl_error($curl);
    } else {
        // Output response
        echo $response;
    }

    // Close cURL session
    curl_close($curl);
} else {
    echo "Phone number is required!";
}
?>
