<?php

$phone = $_REQUEST["phone"];
$random_string = generateRandomString(); // Function to generate a random string
$random_number = generateRandomNumber(); // Function to generate a random number
$email = $random_string . $random_number . "@gmail.com"; // Change example.com to your desired domain

// Function to validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit;
}

$url = "https://app.eonbazar.com/api/auth/register";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Content-Type: application/json",
    "carttoken: 5d7bcfdb-27ae-453f-a4b9-6cf94da73032",
    "ordersource: web",
    "origin: https://eonbazar.com",
    "referer: https://eonbazar.com/",
    "sec-ch-ua: \"Chromium\";v=\"122\", \"Not(A:Brand\";v=\"24\", \"Google Chrome\";v=\"122\"",
    "sec-ch-ua-mobile: ?0",
    "sec-ch-ua-platform: \"Windows\"",
    "sec-fetch-dest: empty",
    "sec-fetch-mode: cors",
    "sec-fetch-site: same-site",
    "x-requested-with: XMLHttpRequest"
);

curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

$data = array(
    "mobile" => $phone,
    "name" => "w8sojib",
    "password" => "Soji12345",
    "email" => $email
);

$data_string = json_encode($data);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

// Set to true for debugging SSL issues
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($curl);
curl_close($curl);

echo $response;

function generateRandomString($length = 10) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomNumber($length = 4) {
    $numbers = '0123456789';
    $numbersLength = strlen($numbers);
    $randomNumber = '';
    for ($i = 0; $i < $length; $i++) {
        $randomNumber .= $numbers[rand(0, $numbersLength - 1)];
    }
    return $randomNumber;
}

?>
