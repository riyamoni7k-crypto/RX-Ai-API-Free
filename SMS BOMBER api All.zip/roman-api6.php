<?php
$phn=$_GET["phone"];
// API endpoint
$url = 'http://103.4.145.86:6005/api/v1/user/otp/send';

// Data to be sent in the request
$data = array(
    'msisdn' => $phn,
    'operator' => 'robi'
);

// JSON encode the data
$data_json = json_encode($data);

// cURL initialization
$ch = curl_init($url);

// Set the cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Authorization: Bearer 2Comics4mh5ln64ron5t26kpvm3toBlog'
));

// Execute the cURL request and capture the response
$response = curl_exec($ch);

// Check for cURL errors
if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die('Curl error: ' . $error);
}

// Close the cURL session
curl_close($ch);

// Print the response
echo 'Response: ' . $response;
?>
