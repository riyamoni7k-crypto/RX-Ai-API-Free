<?php
// Get the phone number from GET parameter
$mobileNo = isset($_GET['phone']) ? $_GET['phone'] : '';

// Validate the number if needed
if (empty($mobileNo)) {
    die("Phone number is required");
}

// API endpoint
$url = 'https://www.88ai99.com/wps/verification/sms/register';

// Request data
$data = [
    'mobileNo' => $mobileNo,
    'countryDialingCode' => '880'
];

// Headers
$headers = [
    'Host: www.88ai99.com',
    'Connection: keep-alive',
    'Content-Length: ' . strlen(json_encode($data)),
    'Language: EN',
    'sec-ch-ua-platform: "Android"',
    'Authorization: ',
    'sec-ch-ua: "Chromium";v="134", "Not:A-Brand";v="24", "Android WebView";v="134"',
    'sec-ch-ua-mobile: ?1',
    'Merchant: ai99bdtf5',
    'ModuleId: REGMOBVERF3',
    'User-Agent: Mozilla/5.0 (Linux; Android 12; itel S665L Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.135 Mobile Safari/537.36',
    'Accept: application/json, text/plain, */*',
    'Content-Type: application/json',
    'Origin: https://www.88ai99.com',
    'X-Requested-With: mark.via.gp',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://www.88ai99.com/m/register?affiliateCode=fbbg01&fbclid=IwY2xjawJbnWVleHRuA2FlbQEwAGFkaWQBqxycFUXH8AEdAFjaMnIw9I-B8TPkoh7IHlxs5lZozJyoGh_mMa4AIYqvxFbnVJSxiHTP_aem_jkB4HHeMVBdq-1voyKgK_Q&fbPixelId=9611996472154703&utm_source=fb',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: SHELL_deviceId=3418f42b-d0ca-4e5f-8e5b-b968deb26410; _fbc=fb.1.1743699541835.IwY2xjawJbnWVleHRuA2FlbQEwAGFkaWQBqxycFUXH8AEdAFjaMnIw9I-B8TPkoh7IHlxs5lZozJyoGh_mMa4AIYqvxFbnVJSxiHTP_aem_jkB4HHeMVBdq-1voyKgK_Q; _fbp=fb.1.1743699541878.955795831363308300; _ss_s_uid=6a3f7ef6db732587e33d7b87a8c41927'
];

// Initialize cURL
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_ENCODING, ''); // Enable compression

// Execute the request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    echo $response;
}

// Close cURL
curl_close($ch);
?>