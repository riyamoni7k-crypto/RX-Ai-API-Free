<?php
// Get and sanitize phone number from the GET request
$phn1 = filter_input(INPUT_GET, 'phone', FILTER_SANITIZE_STRING);

if (!$phn1) {
    echo 'Error: Invalid phone number';
    exit;
}

// Remove leading zero if present
$phn = ltrim($phn1, '0');

// Dynamically construct the URL for url1 based on the current domain
$url1 = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/engage-token.php';

$ch = curl_init($url1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
    curl_close($ch);
    exit;
}
curl_close($ch);

// Extracting aocToken from the response
$data = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo 'Error: Invalid JSON response';
    exit;
}
if (!isset($data['aocToken'])) {
    echo 'Error: aocToken not found in response';
    exit;
}
$aocToken = $data['aocToken'];

// Second request to url2 using aocToken
$url2 = 'http://robi.mife-aoc.com/api/robi/aoc/ask/' . $aocToken;
$data = array(
    'msisdn' => $phn
);

$ch = curl_init($url2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
));

$response = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
    curl_close($ch);
    exit;
}
curl_close($ch);

// Output the response from url2
echo $response;
?>
