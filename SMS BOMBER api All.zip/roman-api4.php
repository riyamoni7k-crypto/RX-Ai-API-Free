<?php

// The phone number to send OTP to
$phn = $_GET['phone'];

// Prepend +88 to the phone number
$phn = '+88' . $phn;

// The API endpoint for sending the OTP
$url = "https://api.medeasy.health/api/send-otp/$phn/";

// Initialize a cURL session
$ch = curl_init();

// Set the URL
curl_setopt($ch, CURLOPT_URL, $url);

// Set the User-Agent to mimic a Googlebot
$userAgent = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);

// Set the request method to GET (default)
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the request and get the response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'cURL error: ' . curl_error($ch);
} else {
    // Output the response
    echo $response;
}

// Close the cURL session
curl_close($ch);
?>