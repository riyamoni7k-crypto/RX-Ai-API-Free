<?php
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';
$countryDialingCode = '880'; // Default to 880 as in your example

// Validate phone number (basic validation)
if (empty($phone)) {
    die("Phone number is required");
}

$url = 'https://www.88001234.com/wps/verification/sms/register';
$data = json_encode([
    'mobileNo' => $phone,
    'countryDialingCode' => $countryDialingCode
]);

$headers = [
    'Host: www.88001234.com',
    'Connection: keep-alive',
    'Content-Length: ' . strlen($data),
    'Language: EN',
    'sec-ch-ua-platform: "Android"',
    'Authorization: ',
    'sec-ch-ua: "Chromium";v="134", "Not:A-Brand";v="24", "Android WebView";v="134"',
    'sec-ch-ua-mobile: ?1',
    'Merchant: bhabdtf5',
    'ModuleId: REGMOBVERF3',
    'User-Agent: Mozilla/5.0 (Linux; Android 12; itel S665L Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.135 Mobile Safari/537.36',
    'Accept: application/json, text/plain, */*',
    'Content-Type: application/json',
    'Origin: https://www.88001234.com',
    'X-Requested-With: mark.via.gp',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://www.88001234.com/m/register?affiliateCode=bhalo88ads2&click_clickid=ZmKZXjXi&tplhx=1&rb_page=1&rb_time=1743907601828&uuid=U2504063923986915702949906&link_id=L2504063443986915761603390400&rb_tid=&rb_clear_source_flag=1&is_open_chrome=1&rb_to=__roibest_scan&channel_id=4&invite_code=&promote_url_id=2310822058&rb_pixel_id=',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: tcg-sid=53d1b9dd-e154-4600-9f36-30645f493b27; SHELL_deviceId=91a50532-447f-4f11-a70b-2d309658b766; _fbp=fb.1.1743907659268.146749242563771597'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate, br, zstd');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
} else {
    echo "HTTP Code: $httpCode\n";
    echo "Response: $response";
}

curl_close($ch);
?>